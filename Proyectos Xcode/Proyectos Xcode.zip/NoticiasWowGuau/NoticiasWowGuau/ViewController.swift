//
//  ViewController.swift
//  NoticiasWowGuau
//
//  Created by Miguel Páez on 11/18/19.
//  Copyright © 2019 Miguel Páez. All rights reserved.
//

import UIKit


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var articles: [Article]? = []
    var myIndex = 0
    var links: [String] = ["https://newsapi.org/v2/top-headlines?q=animal&apiKey=e510d3bfb4be4f198dab60b6e1e5f9ec",
    "https://newsapi.org/v2/top-headlines?q=perro&apiKey=e510d3bfb4be4f198dab60b6e1e5f9ec",
    "https://newsapi.org/v2/top-headlines?q=gato&apiKey=e510d3bfb4be4f198dab60b6e1e5f9ec",
    "https://newsapi.org/v2/top-headlines?q=dog&apiKey=e510d3bfb4be4f198dab60b6e1e5f9ec"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fetchArticles()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("Entré al Segue")
        if  segue.identifier == "segue",
            let destination = segue.destination as? NoticeController,
            let auxIndex = tableView.indexPathForSelectedRow?.row
        {
            destination.titleAux = self.articles?[auxIndex].headline
            destination.contentAux = self.articles?[auxIndex].content
            destination.descLabelAux = self.articles?[auxIndex].desc
            destination.urlImage = self.articles?[auxIndex].imageUrl
            destination.authorAux = self.articles?[auxIndex].author
        }
    }
    
    
    
    

    func fetchArticles(){
        for link in links {
            let urlRequest = URLRequest(url: URL(string: link)!)
            let task = URLSession.shared.dataTask(with: urlRequest) { (data,response,error) in
                
                if error != nil{
                    print(error)
                    return
                }

                
                self.articles = [Article]()
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String:AnyObject]
                    if let articlesFromJson = json["articles"] as? [[String: AnyObject]] {
                        for articleFromJson in articlesFromJson {
                            let article = Article()
                            if let title = articleFromJson["title"] as? String, let author = articleFromJson["author"] as? String, let description = articleFromJson["description"] as? String, let url = articleFromJson["url"] as? String, let urlToImage = articleFromJson["urlToImage"] as? String, let content = articleFromJson["content"] as? String {
                                
                                article.author = author
                                article.headline = title
                                article.desc = description
                                article.url = url
                                article.content = content
                                article.imageUrl = urlToImage
                                
                            }
                            self.articles?.append(article)
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    
                } catch let error {
                    print (error)
                }
                
            }
            task.resume()
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "articleCell", for: indexPath) as! ArticleCell
        cell.title.text = self.articles?[indexPath.item].headline
        
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.articles?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        print (self.articles?[myIndex])
        print (self.articles?[myIndex].headline)
    }
    
}



