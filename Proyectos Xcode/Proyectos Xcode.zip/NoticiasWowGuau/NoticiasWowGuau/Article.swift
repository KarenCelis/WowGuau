//
//  Article.swift
//  NoticiasWowGuau
//
//  Created by Miguel Páez on 11/18/19.
//  Copyright © 2019 Miguel Páez. All rights reserved.
//

import UIKit

class Article: NSObject {
    
    var source: Source?
    var headline: String?
    var desc: String?
    var author: String?
    var url: String?
    var imageUrl: String?
    var publishedAt: String?
    var content: String?

}
