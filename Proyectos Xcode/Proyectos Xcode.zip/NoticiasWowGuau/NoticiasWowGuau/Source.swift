//
//  Source.swift
//  NoticiasWowGuau
//
//  Created by Miguel Páez on 11/18/19.
//  Copyright © 2019 Miguel Páez. All rights reserved.
//

import UIKit

class Source: NSObject {

    var id: String?
    var name: String?
    
}
