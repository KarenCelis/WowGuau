//
//  NoticeController.swift
//  NoticiasWowGuau
//
//  Created by Miguel Páez on 11/19/19.
//  Copyright © 2019 Miguel Páez. All rights reserved.
//

import UIKit

class NoticeController: UIViewController {
    
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    
    var titleAux: String!
    var descLabelAux: String!
    var contentAux: String!
    var urlImage: String!
    var authorAux: String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        titleLabel.text = titleAux
        descLabel.text = descLabelAux
        contentLabel.text = contentAux
        imgView.downlImage(from: (urlImage)!)
        authorLabel.text = authorAux
        
        // Do any additional setup after loading the view.
    }

}

extension UIImageView {
    func downlImage(from url:String){
        let urlRequest = URLRequest(url: URL(string: url)!)
        let task = URLSession.shared.dataTask(with:urlRequest) {(data,response,error) in
            if error != nil{
                print(error)
                return
            }
            
            DispatchQueue.main.async{
                self.image = UIImage(data: data!)
            }
            
        }
        task.resume()
        return
    }
}
